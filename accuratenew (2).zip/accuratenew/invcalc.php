<?php

$Amount = $_POST['amt'];

$quantity = $_POST['qty'];

$price = $_POST['']
?>