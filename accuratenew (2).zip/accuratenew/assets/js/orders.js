$(document).ready(function(){


	alert("hello");

});