function multi(value){
    var rate = document.getElementById('rate');

    var amount;

    amount = rate * value;


    document.getElementById('amountF').value = amount;

}